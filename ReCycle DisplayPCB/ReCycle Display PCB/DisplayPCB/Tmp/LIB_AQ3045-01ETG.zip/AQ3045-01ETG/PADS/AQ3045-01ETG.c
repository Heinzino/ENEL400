*PADS-LIBRARY-SCH-DECALS-V9*

AQ3045-01ETG        32000 32000 100 10 100 10 4 5 0 2 8
TIMESTAMP 2021.08.25.07.11.15
"Default Font"
"Default Font"
500   350   0 0 100 10 "Default Font"
REF-DES
500   250   0 0 100 10 "Default Font"
PART-TYPE
500   -200  0 0 100 10 "Default Font"
*
500   -300  0 0 100 10 "Default Font"
*
CLOSED 4 10 0 -1
400   0    
200   -100 
200   100  
400   0    
CLOSED 4 10 0 -1
400   0    
600   -100 
600   100  
400   0    
OPEN   2 10 0 -1
400   -80  
400   80   
OPEN   2 10 0 -1
360   100  
400   80   
OPEN   2 10 0 -1
400   -80  
440   -100 
T0     0     0 0 0     20    0 0 0     -20   0 32 PIN
P-520  0     0 2 -80   0     0 2 0
T800   0     0 2 0     20    0 0 0     -20   0 32 PIN
P-520  0     0 2 -80   0     0 2 0

*END*